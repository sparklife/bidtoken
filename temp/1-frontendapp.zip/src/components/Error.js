import React, { Component } from 'react';

export class Error extends Component {

  render() {
    return (
      <h1>
          Página não encontrada ou recurso não disponível.
      </h1>
    );
  }
}

